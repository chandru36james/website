import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import ThemeToggle from './ThemeToggle';
import { storage } from '../lib/storage';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [headerContent, setHeaderContent] = useState({
    logoText: 'Singleframe',
    logoImage: '/assets/logo.png',
    bookingCta: 'Book a Shoot'
  });

  const [navLinks, setNavLinks] = useState([
    { name: 'Gallery', path: '/gallery' },
    { name: 'Service', path: '/services' },
    { name: 'Journal', path: '/journal' },
    { name: 'About', path: '/about' },
  ]);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    
    const fetchContent = async () => {
      try {
        // Fetch header content
        const content = await storage.getContent('header');
        if (content) {
          setHeaderContent(prev => ({ ...prev, ...content }));
        }

        // Fetch dynamic pages
        const pages = await storage.getPages();
        const publishedPages = pages.filter((p: any) => p.status === 'published');
        
        if (publishedPages.length > 0) {
          const dynamicLinks = publishedPages.map((p: any) => ({
            name: p.title,
            path: `/p/${p.slug}`
          }));
          
          setNavLinks(prev => {
            // Filter out any existing dynamic links to avoid duplicates
            const staticLinks = prev.filter(link => !link.path.startsWith('/p/'));
            return [...staticLinks, ...dynamicLinks];
          });
        }
      } catch (error) {
        console.error("Error fetching navbar data:", error);
      }
    };
    
    fetchContent();
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled
        ? 'bg-surface/90 backdrop-blur-md border-b border-outline-variant/10 py-3 shadow-lg'
        : 'bg-transparent py-6'
        }`}
    >
      <div className="w-full px-6 md:px-12 flex items-center justify-between">
        {/* LEFT: Logo + Name */}
        <div className="flex items-center gap-4">
          <img
            src={headerContent.logoImage}
            alt="Singleframe Logo"
            className="h-10 w-10 object-cover border border-white/10"
          />

          <Link
            to="/"
            className="text-xl font-headline tracking-tight text-on-surface uppercase font-bold"
          >
            {headerContent.logoText}
          </Link>
        </div>

        {/* DESKTOP NAV */}
        <div className="hidden md:flex items-center gap-12">
          <div className="flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="relative text-[11px] font-bold uppercase tracking-[0.2em] text-on-surface/70 hover:text-on-surface transition"
              >
                {link.name}

                {isActive(link.path) && (
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute left-0 -bottom-1 w-full h-[2px] bg-primary"
                  />
                )}
              </Link>
            ))}
          </div>

          {/* RIGHT ACTIONS */}
          <div className="flex items-center gap-6">
            <ThemeToggle />

            <button
              onClick={() => navigate('/contact')}
              className="px-8 py-3 text-[10px] tracking-[0.2em] uppercase bg-primary text-on-primary hover:bg-primary-container transition font-bold"
            >
              Book a Shoot
            </button>
          </div>
        </div>

        {/* MOBILE TOGGLE */}
        <button
          className="md:hidden text-on-surface p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* MOBILE MENU */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 md:hidden bg-surface flex flex-col"
          >
            <div className="p-6 flex justify-between items-center border-b border-outline-variant/10">
              <div className="flex items-center gap-4">
                <img
                  src={headerContent.logoImage}
                  alt="Singleframe Logo"
                  className="h-10 w-10 object-cover border border-white/10"
                />
                <span className="text-xl font-headline tracking-tight text-on-surface uppercase font-bold">{headerContent.logoText}</span>
              </div>
              <button
                className="text-on-surface p-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <X size={32} />
              </button>
            </div>

            <div className="flex-1 flex flex-col justify-center px-12 gap-8">
              {navLinks.map((link, idx) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + idx * 0.1 }}
                >
                  <Link
                    to={link.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`text-5xl font-headline italic tracking-tighter ${isActive(link.path)
                      ? 'text-primary'
                      : 'text-on-surface'
                      }`}
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
            </div>

            <div className="p-12 border-t border-outline-variant/10 space-y-8">
              <div className="flex justify-between items-center">
                <span className="font-label text-[10px] uppercase tracking-[0.2em] text-on-surface/40">Appearance</span>
                <ThemeToggle />
              </div>
              <button
                onClick={() => {
                  navigate('/contact');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full py-6 bg-primary text-on-primary text-xs tracking-[0.3em] uppercase font-bold shadow-xl"
              >
                {headerContent.bookingCta}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;